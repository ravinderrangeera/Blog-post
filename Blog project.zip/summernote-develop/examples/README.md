Examples
========

This directory contains examples how to use Summernote in various ways.

To add an example, just create a new html file then Webpack dev server will serve it.
By running `yarn dev`, you can access to the index page of examples. The index page will be created from `index.template` file.
